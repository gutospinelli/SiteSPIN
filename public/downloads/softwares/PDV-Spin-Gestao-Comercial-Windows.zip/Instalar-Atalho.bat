@echo off
chcp 65001 >nul
echo ========================================================
echo   PDV SPIN GESTAO COMERCIAL - INSTALADOR DE ATALHOS
echo ========================================================
echo.
set "CURRENT_DIR=%~dp0"
set "EXE_PATH=%CURRENT_DIR%pdvspin.exe"

if not exist "%EXE_PATH%" (
    echo ERRO: Arquivo pdvspin.exe nao encontrado nesta pasta!
    pause
    exit /b 1
)

echo Criando atalhos na Area de Trabalho e Menu Iniciar...

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$s = $ws.CreateShortcut(\"$desktop\PDV Spin Gestão Comercial.lnk\"); " ^
  "$s.TargetPath = '%EXE_PATH%'; " ^
  "$s.WorkingDirectory = '%CURRENT_DIR%'; " ^
  "$s.Description = 'PDV Spin Gestão Comercial'; " ^
  "$s.Save(); " ^
  "$startMenu = [Environment]::GetFolderPath('Programs'); " ^
  "$folder = Join-Path $startMenu 'PDV Spin'; " ^
  "if (!(Test-Path $folder)) { New-Item -ItemType Directory -Path $folder -Force | Out-Null }; " ^
  "$s2 = $ws.CreateShortcut(\"$folder\PDV Spin Gestão Comercial.lnk\"); " ^
  "$s2.TargetPath = '%EXE_PATH%'; " ^
  "$s2.WorkingDirectory = '%CURRENT_DIR%'; " ^
  "$s2.Description = 'PDV Spin Gestão Comercial'; " ^
  "$s2.Save();"

echo.
echo [SUCESSO] Atalhos criados com sucesso!
echo Voce ja pode abrir o PDV Spin diretamente pela Area de Trabalho.
echo.
pause
